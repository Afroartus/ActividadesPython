numeroInicio = 0
numeroFinal = 11


while numeroInicio <= numeroFinal:
    if numeroInicio % 2 != 0:
        print(numeroInicio, "es numero impar")
    numeroInicio += 1