edad = int(input("Cual es su edad: "))

if edad > 17:
    print("El usuario es mayor de edad")
else:
    print("El usuario es menor de edad")