listaNumero = []
for numero in range(1, 101):
    listaNumero.append(numero)

listaOrdenada = sorted(listaNumero, reverse=True)
print(listaOrdenada)